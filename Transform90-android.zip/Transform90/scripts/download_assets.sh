#!/usr/bin/env bash
# Downloads the full open-source exercise dataset (800+ exercises with photos)
# from free-exercise-db (https://github.com/yuhonas/free-exercise-db).
# License: Unlicense (public domain) — safe for commercial use.
#
# Run from the project root:  bash scripts/download_assets.sh
set -e

ASSETS="app/src/main/assets"
TMP=$(mktemp -d)

echo "Downloading free-exercise-db…"
curl -L -o "$TMP/db.zip" https://github.com/yuhonas/free-exercise-db/archive/refs/heads/main.zip
unzip -q "$TMP/db.zip" -d "$TMP"

SRC=$(find "$TMP" -maxdepth 1 -type d -name "free-exercise-db-*")

echo "Installing exercises.json (full dataset)…"
cp "$SRC/dist/exercises.json" "$ASSETS/exercises.json"

echo "Installing exercise photos…"
mkdir -p "$ASSETS/exercises"
cp -r "$SRC/exercises/." "$ASSETS/exercises/"

rm -rf "$TMP"
echo "Done. Rebuild the app — the workout player now shows photos for every exercise."
