package com.transform90.ui.nutrition

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.transform90.domain.PlanGenerator
import com.transform90.ui.dashboard.DashboardViewModel
import androidx.compose.foundation.layout.Column

data class Food(val name: String, val kcal: Int, val protein: Int, val carbs: Int, val fat: Int, val tags: List<String>)

private val proteinFoods = listOf(
    Food("3 whole eggs", 210, 18, 2, 15, listOf("Eggetarian", "Non-Vegetarian")),
    Food("150 g chicken breast", 250, 46, 0, 5, listOf("Non-Vegetarian")),
    Food("150 g fish (grilled)", 220, 40, 0, 6, listOf("Non-Vegetarian")),
    Food("100 g paneer", 265, 18, 4, 20, listOf("Vegetarian", "Eggetarian")),
    Food("100 g tofu", 145, 16, 3, 8, listOf("Vegan", "Vegetarian", "Eggetarian")),
    Food("1 scoop whey + water", 120, 24, 3, 1, listOf("Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("50 g soya chunks (dry)", 170, 26, 15, 1, listOf("Vegan", "Vegetarian", "Eggetarian")),
    Food("200 g Greek yogurt", 130, 20, 8, 2, listOf("Vegetarian", "Eggetarian"))
)
private val carbFoods = listOf(
    Food("1 cup cooked rice", 200, 4, 45, 0, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("2 rotis / phulkas", 180, 6, 36, 2, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("60 g oats", 230, 8, 40, 4, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("3 idlis", 180, 5, 36, 1, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("1 plain dosa", 170, 4, 30, 4, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("150 g sweet potato", 130, 2, 30, 0, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("1 banana", 105, 1, 27, 0, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian"))
)
private val fatFoods = listOf(
    Food("10 almonds", 70, 3, 2, 6, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("1 tbsp peanut butter", 95, 4, 3, 8, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("1 tbsp olive oil", 120, 0, 0, 14, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("1/2 avocado", 120, 1, 6, 11, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian")),
    Food("10 cashews", 90, 3, 5, 7, listOf("Vegan", "Vegetarian", "Eggetarian", "Non-Vegetarian"))
)

@Composable
fun NutritionScreen(vm: DashboardViewModel = hiltViewModel()) {
    val profile by vm.profile.collectAsStateWithLifecycle(initialValue = null)
    val p = profile ?: return
    val t = PlanGenerator.targets(p)
    var group by rememberSaveable { mutableStateOf("Protein") }
    val foods = when (group) { "Protein" -> proteinFoods; "Carbs" -> carbFoods; else -> fatFoods }
        .filter { p.foodPref in it.tags }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Daily targets", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${t.calories} kcal", style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary)
            Text("Protein ${t.proteinG} g · Carbs ${t.carbsG} g · Fat ${t.fatG} g · Fiber ${t.fiberG} g · Water ${t.waterMl / 1000f} L")
            Text("Build each meal: 1 protein + 1 carb + 1 fat + vegetables. Swap freely — macros stay on track.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Protein", "Carbs", "Fats").forEach { g ->
                    FilterChip(selected = group == g, onClick = { group = g }, label = { Text(g) })
                }
            }
        }
        items(foods.size) { i ->
            val f = foods[i]
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(f.name, style = MaterialTheme.typography.titleMedium)
                    Text("${f.kcal} kcal · P ${f.protein} g · C ${f.carbs} g · F ${f.fat} g",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
