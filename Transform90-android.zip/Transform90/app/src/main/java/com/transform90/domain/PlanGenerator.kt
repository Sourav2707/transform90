package com.transform90.domain

import com.transform90.data.model.Exercise
import com.transform90.data.model.UserProfile
import kotlin.math.roundToInt

data class MacroTargets(
    val calories: Int, val proteinG: Int, val carbsG: Int, val fatG: Int,
    val fiberG: Int, val waterMl: Int
)

data class PlannedExercise(val exercise: Exercise, val sets: Int, val reps: String, val restSec: Int)

data class DayPlan(
    val dayNumber: Int,            // 1..90
    val title: String,             // "Push Day", "Rest Day"...
    val focusMuscles: List<String>,
    val exercises: List<PlannedExercise>,
    val cardioMinutes: Int,
    val phase: Int                 // 1..3
)

object PlanGenerator {

    // ---- Calculators (also exposed on the Settings screen) ----

    /** Mifflin-St Jeor */
    fun bmr(p: UserProfile): Int {
        val base = 10 * p.weightKg + 6.25f * p.heightCm - 5 * p.age
        return (if (p.gender == "Male") base + 5 else base - 161).roundToInt()
    }

    fun tdee(p: UserProfile): Int {
        val activity = when (p.daysPerWeek) {
            in 0..2 -> 1.35f
            in 3..4 -> 1.45f
            else -> 1.55f
        }
        return (bmr(p) * activity).roundToInt()
    }

    fun bmi(p: UserProfile): Float {
        val m = p.heightCm / 100f
        return p.weightKg / (m * m)
    }

    fun targets(p: UserProfile): MacroTargets {
        val tdee = tdee(p)
        val calories = when (p.goal) {
            "Muscle Gain" -> tdee + 250
            "Lean Muscle", "Body Recomposition" -> tdee - 250
            else -> (tdee - 550).coerceAtLeast(1400)     // Weight/Fat Loss
        }
        val protein = (p.weightKg * 1.8f).roundToInt()   // g
        val fat = (calories * 0.25f / 9f).roundToInt()
        val carbs = ((calories - protein * 4 - fat * 9) / 4f).coerceAtLeast(80f).roundToInt()
        val water = ((p.weightKg * 35).roundToInt() + if (p.daysPerWeek >= 5) 500 else 250)
        return MacroTargets(calories, protein, carbs, fat, 30, water)
    }

    // ---- 90-day plan ----

    private val splits: Map<Int, List<List<String>>> = mapOf(
        3 to listOf(
            listOf("chest", "shoulders", "triceps"),
            listOf("lats", "middle back", "biceps"),
            listOf("quadriceps", "hamstrings", "glutes", "calves")
        ),
        4 to listOf(
            listOf("chest", "triceps"),
            listOf("lats", "middle back", "biceps"),
            listOf("quadriceps", "hamstrings", "calves"),
            listOf("shoulders", "abdominals")
        ),
        5 to listOf(
            listOf("chest", "triceps"),
            listOf("lats", "middle back", "biceps"),
            listOf("quadriceps", "hamstrings", "glutes", "calves"),
            listOf("shoulders", "traps"),
            listOf("abdominals", "lower back")
        ),
        6 to listOf(
            listOf("chest", "shoulders", "triceps"),
            listOf("lats", "middle back", "biceps"),
            listOf("quadriceps", "hamstrings", "glutes", "calves"),
            listOf("chest", "triceps"),
            listOf("lats", "biceps", "traps"),
            listOf("quadriceps", "abdominals", "calves")
        )
    )

    private val titles = mapOf(
        "chest" to "Push Day", "lats" to "Pull Day", "quadriceps" to "Leg Day",
        "shoulders" to "Shoulder Day", "abdominals" to "Core Day"
    )

    fun planForDay(day: Int, p: UserProfile, library: List<Exercise>): DayPlan {
        val phase = ((day - 1) / 30) + 1
        val split = splits[p.daysPerWeek.coerceIn(3, 6)] ?: splits.getValue(4)
        val weekSlot = (day - 1) % 7                       // 0..6

        if (weekSlot >= split.size) {
            return DayPlan(day, if (weekSlot == 6) "Rest Day" else "Active Recovery",
                emptyList(), emptyList(), if (weekSlot == 6) 0 else 40, phase)
        }

        val muscles = split[weekSlot]
        val equipmentOk: (Exercise) -> Boolean = { e ->
            if (p.location == "Gym") true
            else e.equipment in listOf("body only", "dumbbell", "bands", "kettlebells", "other")
        }
        val levelRank = mapOf("beginner" to 0, "intermediate" to 1, "expert" to 2)
        val maxLevel = when (p.fitnessLevel) {
            "Beginner" -> 0; "Intermediate" -> 1; else -> 2
        }

        val perMuscle = (p.durationMin / 15).coerceIn(1, 3)
        val chosen = mutableListOf<Exercise>()
        for (m in muscles) {
            library.asSequence()
                .filter { it.primaryMuscles.any { pm -> pm.equals(m, true) } }
                .filter(equipmentOk)
                .filter { (levelRank[it.level] ?: 0) <= maxLevel }
                .sortedBy { it.id.hashCode() xor (day * 31) }   // deterministic weekly variety
                .take(perMuscle)
                .forEach { if (chosen.none { c -> c.id == it.id }) chosen.add(it) }
        }

        val (sets, reps, rest) = when (phase) {
            1 -> Triple(3, "12", 75)
            2 -> Triple(4, "10", 90)
            else -> Triple(4, "8-10", 90)
        }
        val cardio = when (phase) { 1 -> 25; 2 -> 30; else -> 35 }
        val title = titles[muscles.first()] ?: "Training Day"

        return DayPlan(day, title, muscles,
            chosen.map { PlannedExercise(it, sets, reps, rest) }, cardio, phase)
    }
}
