package com.transform90.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.transform90.data.db.ProfileDao
import com.transform90.data.model.UserProfile
import com.transform90.reminders.Reminders
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import android.content.Context
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val dao: ProfileDao,
    @ApplicationContext private val ctx: Context
) : ViewModel() {
    fun save(p: UserProfile) = viewModelScope.launch {
        dao.save(p)
        Reminders.scheduleAll(ctx, p.wakeTime, p.sleepTime)
    }
}

@Composable
fun OnboardingScreen(vm: OnboardingViewModel = hiltViewModel()) {
    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var bodyFat by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("Male") }
    var level by remember { mutableStateOf("Beginner") }
    var goal by remember { mutableStateOf("Fat Loss") }
    var location by remember { mutableStateOf("Gym") }
    var food by remember { mutableStateOf("Non-Vegetarian") }
    var days by remember { mutableStateOf(6) }
    var duration by remember { mutableStateOf(60) }
    var wake by remember { mutableStateOf("06:30") }
    var sleep by remember { mutableStateOf("22:30") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("TRANSFORM 90", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)
        Text("Answer once — the app builds your personal 90-day plan.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(age, { age = it }, label = { Text("Age") }, modifier = Modifier.weight(1f))
            OutlinedTextField(height, { height = it }, label = { Text("Height cm") }, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(weight, { weight = it }, label = { Text("Weight kg") }, modifier = Modifier.weight(1f))
            OutlinedTextField(target, { target = it }, label = { Text("Target kg") }, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(bodyFat, { bodyFat = it }, label = { Text("Body fat % (optional)") },
            modifier = Modifier.fillMaxWidth())

        ChipRow("Gender", listOf("Male", "Female"), gender) { gender = it }
        ChipRow("Level", listOf("Beginner", "Intermediate", "Advanced"), level) { level = it }
        ChipRow("Goal", listOf("Fat Loss", "Weight Loss", "Lean Muscle", "Muscle Gain", "Body Recomposition"), goal) { goal = it }
        ChipRow("Where", listOf("Gym", "Home"), location) { location = it }
        ChipRow("Food", listOf("Vegetarian", "Eggetarian", "Non-Vegetarian", "Vegan"), food) { food = it }
        ChipRow("Days / week", listOf("3", "4", "5", "6"), days.toString()) { days = it.toInt() }
        ChipRow("Duration", listOf("20", "30", "45", "60", "90"), duration.toString()) { duration = it.toInt() }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(wake, { wake = it }, label = { Text("Wake (HH:mm)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(sleep, { sleep = it }, label = { Text("Sleep (HH:mm)") }, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(4.dp))
        Button(
            onClick = {
                vm.save(
                    UserProfile(
                        name = name.ifBlank { "Athlete" },
                        age = age.toIntOrNull() ?: 25,
                        gender = gender,
                        heightCm = height.toFloatOrNull() ?: 170f,
                        weightKg = weight.toFloatOrNull() ?: 75f,
                        targetWeightKg = target.toFloatOrNull() ?: 70f,
                        bodyFatPct = bodyFat.toFloatOrNull(),
                        fitnessLevel = level,
                        goal = goal,
                        location = location,
                        daysPerWeek = days,
                        durationMin = duration,
                        foodPref = food,
                        wakeTime = wake,
                        sleepTime = sleep,
                        startEpochDay = LocalDate.now().toEpochDay()
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("START DAY 1") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ChipRow(label: String, options: List<String>, selected: String, onPick: (String) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { o ->
                FilterChip(selected = selected == o, onClick = { onPick(o) }, label = { Text(o) })
            }
        }
    }
}
