package com.transform90.data

import android.content.Context
import com.transform90.data.model.Exercise
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

/**
 * Loads the exercise library from assets/exercises.json.
 *
 * The JSON follows the schema of the open-source "free-exercise-db"
 * (https://github.com/yuhonas/free-exercise-db, public domain / Unlicense).
 * Run scripts/download_assets.sh to replace the bundled starter set with
 * the full 800+ exercise dataset including photos.
 */
class ExerciseRepository(private val ctx: Context) {

    @Volatile private var cache: List<Exercise>? = null

    suspend fun all(): List<Exercise> = cache ?: withContext(Dispatchers.IO) {
        val json = ctx.assets.open("exercises.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(json)
        val list = buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    Exercise(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        category = o.optString("category", "strength"),
                        primaryMuscles = o.optJSONArray("primaryMuscles").toStringList(),
                        secondaryMuscles = o.optJSONArray("secondaryMuscles").toStringList(),
                        equipment = o.optString("equipment", "body only"),
                        level = o.optString("level", "beginner"),
                        instructions = o.optJSONArray("instructions").toStringList(),
                        images = o.optJSONArray("images").toStringList()
                    )
                )
            }
        }
        cache = list
        list
    }

    suspend fun byId(id: String): Exercise? = all().firstOrNull { it.id == id }

    suspend fun search(query: String, muscle: String?, equipment: String?): List<Exercise> =
        all().filter { e ->
            (query.isBlank() || e.name.contains(query, ignoreCase = true)) &&
            (muscle == null || e.primaryMuscles.any { it.equals(muscle, true) }) &&
            (equipment == null || e.equipment.equals(equipment, true))
        }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return List(length()) { getString(it) }
    }
}
