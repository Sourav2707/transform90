package com.transform90.domain

import com.transform90.data.model.Exercise

/**
 * Fixed Day1–Day6 split, built from the user-provided workout video.
 * Day7 (Sunday) is rest.
 *
 * Clips live at assets/videos/<dayKey>/<Name>.mp4 — filenames below must
 * match exactly what scripts left in app/src/main/assets/videos/.
 */
object WorkoutPlan {

    private fun ex(id: String, name: String, day: String, sets: Int, reps: String) =
        Exercise(id, name, day, "videos/$day/$id.mp4", sets, reps)

    val days: Map<String, List<Exercise>> = linkedMapOf(
        "day1" to listOf( // Chest
            ex("Barbell-Flat-Bench-Press", "Barbell Flat Bench Press", "day1", 3, "8-12"),
            ex("Barbell-Incline-Bench-Press", "Barbell Incline Bench Press", "day1", 3, "8-12"),
            ex("Barbell-Decline-Bench-Press", "Barbell Decline Bench Press", "day1", 3, "8-12"),
            ex("Pec-Deck-Fly", "Pec Deck Fly (Machine)", "day1", 3, "10-15"),
            ex("Standing-Cable-Fly", "Standing Cable Fly", "day1", 3, "10-15"),
            ex("High-Cable-Fly-Crossover", "High Cable Fly (Cross Over)", "day1", 3, "10-15"),
            ex("Low-Standing-Cable-Fly", "Low Standing Cable Fly", "day1", 3, "10-15"),
        ),
        "day2" to listOf( // Lats / Mid-back / Lower back
            ex("Lat-Pulldown-Wide-Grip", "Lat Pull-Down (Wide Grip)", "day2", 3, "8-12"),
            ex("Seated-Cable-Row", "Seated Cable Row", "day2", 3, "8-12"),
            ex("Deadlift", "Deadlift", "day2", 3, "6-10"),
            ex("Bent-Over-Row", "Bent Over Row", "day2", 3, "8-12"),
            ex("Hyperextension", "Hyper Extension", "day2", 3, "12-15"),
        ),
        "day3" to listOf( // Biceps / Forearms
            ex("Dumbbell-Bicep-Curl", "Dumbbell Bicep Curl", "day3", 3, "10-12"),
            ex("Close-Grip-EZ-Bar-Curl", "Close-Grip EZ Bar Curl", "day3", 3, "10-12"),
            ex("EZ-Bar-Preacher-Curl", "EZ-Bar Preacher Curl", "day3", 3, "10-12"),
            ex("Dumbbell-Hammer-Preacher-Curl", "Dumbbell Hammer Preacher Curl", "day3", 3, "10-12"),
            ex("Dumbbell-Reverse-Curl", "Dumbbell Reverse Curl", "day3", 3, "10-12"),
            ex("Seated-Barbell-Wrist-Curl", "Seated Barbell Wrist Curl", "day3", 1, "15-20"),
        ),
        "day4" to listOf( // Triceps + Abs
            ex("Triceps-Bench-Dips", "Triceps Bench Dips", "day4", 3, "10-12"),
            ex("Dumbbell-Overhead-Extension", "Dumbbell Overhead Extension", "day4", 3, "10-12"),
            ex("Pulley-Push-Down", "Pulley Push Down", "day4", 3, "10-12"),
            ex("Dumbbell-Kickback", "Dumbbell Kick Back", "day4", 3, "10-12"),
            ex("Sit-Ups", "Sit-Ups", "day4", 3, "15"),
            ex("Bicycle-Crunches", "Bicycle Crunches", "day4", 3, "15"),
            ex("Incline-Straight-Leg-Hip-Raise", "Incline Straight Leg & Hip Raise", "day4", 3, "15"),
            ex("Hanging-Knee-Leg-Raise", "Hanging Knee & Leg Raises", "day4", 3, "15"),
            ex("Seated-V-Sits", "Seated V Sits", "day4", 3, "15"),
            ex("Weighted-Russian-Twist", "Weighted Russian Twist", "day4", 3, "15"),
            ex("Weighted-Sit-Ups", "Weighted Sit Ups", "day4", 3, "15"),
        ),
        "day5" to listOf( // Shoulders + Traps
            ex("Dumbbell-Side-Raise", "Dumbbell Side Raise", "day5", 3, "10-15"),
            ex("Dumbbell-Front-Raise", "Dumbbell Front Raise", "day5", 3, "10-15"),
            ex("Dumbbell-Shoulder-Press-Seated", "Dumbbell Shoulder Press (Seated)", "day5", 3, "8-12"),
            ex("Front-Raise-Cable", "Front Raise (Cable)", "day5", 3, "10-15"),
            ex("Reverse-Pec-Deck", "Reverse Pec Deck", "day5", 3, "10-15"),
            ex("Face-Pulls", "Face Pulls", "day5", 3, "12-15"),
            ex("Dumbbell-Shrugs", "Dumbbell Shrugs", "day5", 3, "10-15"),
        ),
        "day6" to listOf( // Legs
            ex("Barbell-Squat-Back", "Barbell Squat (Back)", "day6", 3, "8-12"),
            ex("Barbell-Lunges", "Barbell Lunges", "day6", 3, "10-12"),
            ex("Hip-Thrust", "Hip Thrust", "day6", 3, "10-12"),
            ex("Leg-Press", "Leg Press", "day6", 3, "10-12"),
            ex("Leg-Extension", "Leg Extension", "day6", 3, "12-15"),
            ex("Lying-Leg-Curls", "Laying Leg Curls", "day6", 3, "12-15"),
            ex("Seated-Calf-Raise", "Seated Calf Raise", "day6", 3, "15-20"),
        ),
    )

    val titles = mapOf(
        "day1" to "Chest", "day2" to "Back", "day3" to "Biceps & Forearms",
        "day4" to "Triceps & Abs", "day5" to "Shoulders & Traps", "day6" to "Legs"
    )

    val dayKeys = listOf("day1", "day2", "day3", "day4", "day5", "day6") // day7 = rest

    /** Maps the 90-day counter onto the fixed 6-day + 1-rest weekly cycle. */
    fun dayKeyFor(dayNumber: Int): String? {
        val slot = (dayNumber - 1) % 7
        return if (slot < 6) dayKeys[slot] else null // null = Sunday rest
    }

    fun allExercises(): List<Exercise> = days.values.flatten()
}
