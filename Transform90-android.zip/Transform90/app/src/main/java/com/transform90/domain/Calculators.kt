package com.transform90.domain

import com.transform90.data.model.UserProfile
import kotlin.math.roundToInt

data class MacroTargets(
    val calories: Int, val proteinG: Int, val carbsG: Int, val fatG: Int,
    val fiberG: Int, val waterMl: Int
)

object PlanGenerator {

    fun bmr(p: UserProfile): Int {
        val base = 10 * p.weightKg + 6.25f * p.heightCm - 5 * p.age
        return (if (p.gender == "Male") base + 5 else base - 161).roundToInt()
    }

    fun tdee(p: UserProfile): Int {
        val activity = when (p.daysPerWeek) {
            in 0..2 -> 1.35f
            in 3..4 -> 1.45f
            else -> 1.55f
        }
        return (bmr(p) * activity).roundToInt()
    }

    fun bmi(p: UserProfile): Float {
        val m = p.heightCm / 100f
        return p.weightKg / (m * m)
    }

    fun targets(p: UserProfile): MacroTargets {
        val tdee = tdee(p)
        val calories = when (p.goal) {
            "Muscle Gain" -> tdee + 250
            "Lean Muscle", "Body Recomposition" -> tdee - 250
            else -> (tdee - 550).coerceAtLeast(1400)
        }
        val protein = (p.weightKg * 1.8f).roundToInt()
        val fat = (calories * 0.25f / 9f).roundToInt()
        val carbs = ((calories - protein * 4 - fat * 9) / 4f).coerceAtLeast(80f).roundToInt()
        val water = ((p.weightKg * 35).roundToInt() + if (p.daysPerWeek >= 5) 500 else 250)
        return MacroTargets(calories, protein, carbs, fat, 30, water)
    }
}
