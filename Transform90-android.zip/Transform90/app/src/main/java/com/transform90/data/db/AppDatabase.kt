package com.transform90.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.transform90.data.model.DailyLog
import com.transform90.data.model.SetLog
import com.transform90.data.model.UserProfile
import com.transform90.data.model.WeightEntry

@Database(
    entities = [UserProfile::class, DailyLog::class, WeightEntry::class, SetLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun logDao(): LogDao
}
