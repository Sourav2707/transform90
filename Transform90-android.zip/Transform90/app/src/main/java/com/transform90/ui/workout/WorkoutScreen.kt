package com.transform90.ui.workout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.transform90.data.ExerciseRepository
import com.transform90.data.db.LogDao
import com.transform90.data.db.ProfileDao
import com.transform90.data.model.DailyLog
import com.transform90.domain.DayPlan
import com.transform90.domain.PlanGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class WorkoutViewModel @Inject constructor(
    private val profileDao: ProfileDao,
    private val logDao: LogDao,
    private val exercises: ExerciseRepository
) : ViewModel() {

    val plan = MutableStateFlow<DayPlan?>(null)

    init {
        viewModelScope.launch {
            val p = profileDao.profile().first() ?: return@launch
            val day = ((LocalDate.now().toEpochDay() - p.startEpochDay).toInt() + 1).coerceIn(1, 90)
            plan.value = PlanGenerator.planForDay(day, p, exercises.all())
        }
    }

    fun markDone() = viewModelScope.launch {
        val day = LocalDate.now().toEpochDay()
        val cur = logDao.day(day).first() ?: DailyLog(day)
        logDao.upsert(cur.copy(workoutDone = true))
    }
}

@Composable
fun WorkoutScreen(vm: WorkoutViewModel = hiltViewModel()) {
    val plan by vm.plan.collectAsStateWithLifecycle()
    val dp = plan ?: return
    var playerIndex by rememberSaveable { mutableIntStateOf(-1) }

    if (playerIndex >= 0 && playerIndex < dp.exercises.size) {
        Player(
            dp = dp,
            index = playerIndex,
            onNext = {
                if (playerIndex == dp.exercises.lastIndex) {
                    vm.markDone(); playerIndex = -1
                } else playerIndex++
            },
            onExit = { playerIndex = -1 }
        )
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Day ${dp.dayNumber} · Phase ${dp.phase}",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(dp.title, style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary)
            Text("Cardio: ${dp.cardioMinutes} min after lifting",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(dp.exercises) { pe ->
            Card {
                Column(Modifier.padding(14.dp)) {
                    Text(pe.exercise.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${pe.sets} sets × ${pe.reps} reps · rest ${pe.restSec}s · " +
                            pe.exercise.primaryMuscles.joinToString(),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            if (dp.exercises.isNotEmpty()) {
                Button(onClick = { playerIndex = 0 },
                    modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("START WORKOUT")
                }
            } else {
                Text("Recovery day — walk, stretch, sleep well.",
                    style = MaterialTheme.typography.titleMedium)
                Button(onClick = { vm.markDone() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Mark day complete")
                }
            }
        }
    }
}

@Composable
private fun Player(dp: DayPlan, index: Int, onNext: () -> Unit, onExit: () -> Unit) {
    val pe = dp.exercises[index]
    var resting by rememberSaveable { mutableStateOf(false) }
    var setNo by rememberSaveable { mutableIntStateOf(1) }
    var restLeft by rememberSaveable { mutableIntStateOf(pe.restSec) }

    LaunchedEffect(resting, restLeft) {
        if (resting && restLeft > 0) { delay(1000); restLeft-- }
        if (resting && restLeft == 0) {
            resting = false
            if (setNo < pe.sets) setNo++ else { setNo = 1; onNext() }
            restLeft = pe.restSec
        }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        LinearProgressIndicator(
            progress = { (index + 1) / dp.exercises.size.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Exercise ${index + 1} of ${dp.exercises.size}",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(pe.exercise.name, style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)

        // Open-source illustration (free-exercise-db image, bundled in assets)
        pe.exercise.images.firstOrNull()?.let { img ->
            AsyncImage(
                model = "file:///android_asset/$img",
                contentDescription = pe.exercise.name,
                modifier = Modifier.fillMaxWidth().height(220.dp),
                contentScale = ContentScale.Fit
            )
        }

        Text("Set $setNo of ${pe.sets} · ${pe.reps} reps",
            style = MaterialTheme.typography.titleLarge)

        if (resting) {
            Text("REST  ${restLeft}s", style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.secondary)
        } else {
            pe.exercise.instructions.take(3).forEach {
                Text("• $it", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = onExit, modifier = Modifier.weight(1f)) { Text("Exit") }
            OutlinedButton(onClick = { setNo = 1; onNext() }, modifier = Modifier.weight(1f)) { Text("Skip") }
            Button(
                onClick = { if (!resting) { resting = true; restLeft = pe.restSec } },
                modifier = Modifier.weight(1.4f)
            ) { Text(if (resting) "Resting…" else "Set done") }
        }
    }
}
