package com.transform90.ui.workout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.transform90.data.db.LogDao
import com.transform90.data.db.ProfileDao
import com.transform90.data.db.ProgressionDao
import com.transform90.data.model.DailyLog
import com.transform90.data.model.Exercise
import com.transform90.data.model.ExerciseWeight
import com.transform90.data.model.SetLog
import com.transform90.domain.Progression
import com.transform90.domain.WorkoutPlan
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class WorkoutViewModel @Inject constructor(
    private val profileDao: ProfileDao,
    private val logDao: LogDao,
    private val progressionDao: ProgressionDao
) : ViewModel() {

    private val todayEpoch = LocalDate.now().toEpochDay()

    var selectedDayKey by mutableStateOf<String?>(null)
        private set

    val weights = progressionDao.all()
        .map { list -> list.associateBy { it.exerciseId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    init {
        viewModelScope.launch {
            val p = profileDao.profile().first()
            val day = p?.let { ((LocalDate.now().toEpochDay() - it.startEpochDay).toInt() + 1).coerceIn(1, 90) } ?: 1
            selectedDayKey = WorkoutPlan.dayKeyFor(day) ?: "day1"
        }
    }

    fun selectDay(key: String) { selectedDayKey = key }

    fun setStartingWeight(exerciseId: String, kg: Float) = viewModelScope.launch {
        progressionDao.upsert(ExerciseWeight(exerciseId, kg, 2.5f, todayEpoch))
    }

    fun logSet(exerciseId: String, setIndex: Int, weightKg: Float, reps: Int) = viewModelScope.launch {
        logDao.addSet(SetLog(epochDay = todayEpoch, exerciseId = exerciseId, setIndex = setIndex, weightKg = weightKg, reps = reps))
    }

    fun markDone() = viewModelScope.launch {
        val cur = logDao.day(todayEpoch).first() ?: DailyLog(todayEpoch)
        logDao.upsert(cur.copy(workoutDone = true))
    }
}

@Composable
fun WorkoutScreen(vm: WorkoutViewModel = hiltViewModel()) {
    val weights by vm.weights.collectAsStateWithLifecycle()
    val dayKey = vm.selectedDayKey ?: return
    val exercises = WorkoutPlan.days[dayKey].orEmpty()
    val todayEpoch = LocalDate.now().toEpochDay()
    var playerIndex by rememberSaveable { mutableIntStateOf(-1) }

    if (playerIndex >= 0 && playerIndex < exercises.size) {
        Player(
            exercise = exercises[playerIndex],
            weight = weights[exercises[playerIndex].id],
            todayEpoch = todayEpoch,
            onSetStarting = { kg -> vm.setStartingWeight(exercises[playerIndex].id, kg) },
            onLogSet = { setNo, kg, reps -> vm.logSet(exercises[playerIndex].id, setNo, kg, reps) },
            onNext = {
                if (playerIndex == exercises.lastIndex) { vm.markDone(); playerIndex = -1 }
                else playerIndex++
            },
            onExit = { playerIndex = -1 }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        LazyRow(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(WorkoutPlan.dayKeys) { key ->
                FilterChip(
                    selected = dayKey == key,
                    onClick = { vm.selectDay(key) },
                    label = { Text("Day ${WorkoutPlan.dayKeys.indexOf(key) + 1}") }
                )
            }
        }
        Text(
            WorkoutPlan.titles[dayKey] ?: "",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LazyColumn(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(exercises) { e ->
                val w = weights[e.id]
                Card {
                    Column(Modifier.padding(14.dp)) {
                        LoopingAssetVideo(e.videoPath, Modifier.fillMaxWidth().height(180.dp))
                        Text(e.name, style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 8.dp))
                        Text(
                            "${e.sets} sets × ${e.repRange} reps" +
                                if (w != null) " · this week ${Progression.targetWeightKg(w, todayEpoch)} kg"
                                else " · tap to set starting weight",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                Button(
                    onClick = { playerIndex = 0 },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("START WORKOUT") }
            }
        }
    }
}

@Composable
private fun Player(
    exercise: Exercise,
    weight: ExerciseWeight?,
    todayEpoch: Long,
    onSetStarting: (Float) -> Unit,
    onLogSet: (Int, Float, Int) -> Unit,
    onNext: () -> Unit,
    onExit: () -> Unit
) {
    var startInput by rememberSaveable { mutableStateOf("") }
    var resting by rememberSaveable { mutableStateOf(false) }
    var setNo by rememberSaveable { mutableIntStateOf(1) }
    val restSec = 75
    var restLeft by rememberSaveable { mutableIntStateOf(restSec) }
    val targetWeight = weight?.let { Progression.targetWeightKg(it, todayEpoch) }
    var repsInput by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(resting, restLeft) {
        if (resting && restLeft > 0) { delay(1000); restLeft-- }
        if (resting && restLeft == 0) {
            resting = false
            if (setNo < exercise.sets) setNo++ else { setNo = 1; onNext() }
            restLeft = restSec
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(exercise.name, style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary)
        LoopingAssetVideo(exercise.videoPath, Modifier.fillMaxWidth().height(220.dp))

        if (weight == null) {
            Text("Set your starting weight for this exercise",
                style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(startInput, { startInput = it }, label = { Text("kg") },
                    modifier = Modifier.weight(1f))
                Button(onClick = { startInput.toFloatOrNull()?.let(onSetStarting) }) { Text("Save") }
            }
            Text("The app adds +2.5 kg every week from here automatically.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@Column
        }

        Text("Set $setNo of ${exercise.sets} · target ${exercise.repRange} reps",
            style = MaterialTheme.typography.titleLarge)
        Text("This week's target weight: ${targetWeight} kg",
            style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)

        if (resting) {
            Text("REST  ${restLeft}s", style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.secondary)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(repsInput, { repsInput = it }, label = { Text("Reps done") },
                    modifier = Modifier.weight(1f))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = onExit, modifier = Modifier.weight(1f)) { Text("Exit") }
            OutlinedButton(
                onClick = { setNo = 1; repsInput = ""; onNext() },
                modifier = Modifier.weight(1f)
            ) { Text("Skip") }
            Button(
                onClick = {
                    if (!resting) {
                        val reps = repsInput.toIntOrNull() ?: 0
                        onLogSet(setNo, targetWeight ?: 0f, reps)
                        resting = true; restLeft = restSec; repsInput = ""
                    }
                },
                modifier = Modifier.weight(1.4f)
            ) { Text(if (resting) "Resting…" else "Set done") }
        }
    }
}
