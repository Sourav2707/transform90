package com.transform90.di

import android.content.Context
import androidx.room.Room
import com.transform90.data.db.AppDatabase
import com.transform90.data.db.LogDao
import com.transform90.data.db.ProfileDao
import com.transform90.data.db.ProgressionDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun db(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "t90.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun profileDao(db: AppDatabase): ProfileDao = db.profileDao()
    @Provides fun logDao(db: AppDatabase): LogDao = db.logDao()
    @Provides fun progressionDao(db: AppDatabase): ProgressionDao = db.progressionDao()
}
