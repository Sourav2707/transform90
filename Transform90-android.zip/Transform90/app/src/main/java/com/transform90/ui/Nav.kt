package com.transform90.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.transform90.ui.dashboard.DashboardScreen
import com.transform90.ui.dashboard.DashboardViewModel
import com.transform90.ui.nutrition.NutritionScreen
import com.transform90.ui.onboarding.OnboardingScreen
import com.transform90.ui.progress.ProgressScreen
import com.transform90.ui.settings.SettingsScreen
import com.transform90.ui.workout.WorkoutScreen
import kotlinx.coroutines.flow.first

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun AppNav(vm: DashboardViewModel = hiltViewModel()) {
    var loaded by remember { mutableStateOf(false) }
    val profile by vm.profile.collectAsStateWithLifecycle(initialValue = null)
    LaunchedEffect(Unit) {
        vm.profile.first()
        loaded = true
    }
    if (!loaded) return
    if (profile == null) { OnboardingScreen(); return }

    val nav = rememberNavController()
    val tabs = listOf(
        Tab("home", "Home", Icons.Filled.Home),
        Tab("workout", "Workout", Icons.Filled.FitnessCenter),
        Tab("nutrition", "Diet", Icons.Filled.RestaurantMenu),
        Tab("progress", "Progress", Icons.Filled.Insights),
        Tab("settings", "More", Icons.Filled.Settings),
    )

    Scaffold(bottomBar = {
        val current by nav.currentBackStackEntryAsState()
        NavigationBar {
            tabs.forEach { t ->
                NavigationBarItem(
                    selected = current?.destination?.route == t.route,
                    onClick = { nav.navigate(t.route) { popUpTo("home"); launchSingleTop = true } },
                    icon = { Icon(t.icon, contentDescription = t.label) },
                    label = { Text(t.label) }
                )
            }
        }
    }) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { DashboardScreen(onStartWorkout = { nav.navigate("workout") }) }
            composable("workout") { WorkoutScreen() }
            composable("nutrition") { NutritionScreen() }
            composable("progress") { ProgressScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
