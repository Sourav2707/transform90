package com.transform90.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ember = Color(0xFFFF7A29)
val Amber = Color(0xFFFFB020)
val Ink = Color(0xFF14161A)
val Card = Color(0xFF1D2026)
val Mist = Color(0xFF9AA0A8)

private val DarkScheme = darkColorScheme(
    primary = Ember,
    onPrimary = Ink,
    secondary = Amber,
    background = Ink,
    surface = Card,
    onBackground = Color(0xFFE8EAED),
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = Color(0xFF2A2E35),
    onSurfaceVariant = Mist
)

private val LightScheme = lightColorScheme(
    primary = Ember,
    secondary = Amber,
    background = Color(0xFFFAF7F2),
    surface = Color.White
)

@Composable
fun T90Theme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content
    )
}
