package com.transform90.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.transform90.data.db.LogDao
import com.transform90.data.db.ProfileDao
import com.transform90.data.model.DailyLog
import com.transform90.data.model.UserProfile
import com.transform90.domain.PlanGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val profileDao: ProfileDao,
    private val logDao: LogDao
) : ViewModel() {

    val profile = profileDao.profile()

    private val todayEpoch = LocalDate.now().toEpochDay()
    val todayLog = logDao.day(todayEpoch)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun dayNumber(p: UserProfile): Int =
        ((LocalDate.now().toEpochDay() - p.startEpochDay).toInt() + 1).coerceIn(1, 90)

    fun addWater(ml: Int) = viewModelScope.launch {
        val cur = logDao.day(todayEpoch).first() ?: DailyLog(todayEpoch)
        logDao.upsert(cur.copy(waterMl = cur.waterMl + ml))
    }

    fun mealDone() = viewModelScope.launch {
        val cur = logDao.day(todayEpoch).first() ?: DailyLog(todayEpoch)
        logDao.upsert(cur.copy(mealsDone = (cur.mealsDone + 1).coerceAtMost(5)))
    }

    fun supplementDone() = viewModelScope.launch {
        val cur = logDao.day(todayEpoch).first() ?: DailyLog(todayEpoch)
        logDao.upsert(cur.copy(supplementsDone = (cur.supplementsDone + 1).coerceAtMost(4)))
    }
}

private val quotes = listOf(
    "Discipline beats motivation — show up anyway.",
    "You don't have to be extreme, just consistent.",
    "The body achieves what the mind believes.",
    "Sweat now, shine on Day 90.",
    "Small daily wins become massive results."
)

@Composable
fun DashboardScreen(
    onStartWorkout: () -> Unit,
    vm: DashboardViewModel = hiltViewModel()
) {
    val profile by vm.profile.collectAsStateWithLifecycle(initialValue = null)
    val log by vm.todayLog.collectAsStateWithLifecycle()
    val p = profile ?: return
    val day = vm.dayNumber(p)
    val targets = PlanGenerator.targets(p)
    val l = log ?: DailyLog(0)

    val pct = listOf(
        if (l.workoutDone) 1f else 0f,
        (l.waterMl / targets.waterMl.toFloat()).coerceAtMost(1f),
        l.mealsDone / 5f,
        l.supplementsDone / 2f
    ).average().toFloat()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Hi ${p.name}", style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Day $day / 90", style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary)
            }
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(progress = { pct }, modifier = Modifier.size(64.dp))
                Text("${(pct * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Today's workout", style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (l.workoutDone) "Completed ✓" else "Not done yet",
                    style = MaterialTheme.typography.titleLarge)
                Button(onClick = onStartWorkout, modifier = Modifier.fillMaxWidth()) {
                    Text(if (l.workoutDone) "View workout" else "Start workout")
                }
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Water  ${l.waterMl} / ${targets.waterMl} ml",
                    style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(
                    progress = { (l.waterMl / targets.waterMl.toFloat()).coerceAtMost(1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(250, 500, 750, 1000).forEach { ml ->
                        OutlinedButton(onClick = { vm.addWater(ml) }, modifier = Modifier.weight(1f)) {
                            Text(if (ml == 1000) "1 L" else "$ml")
                        }
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.weight(1f)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Meals ${l.mealsDone}/5", style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = { vm.mealDone() }) { Text("+ meal") }
                }
            }
            Card(Modifier.weight(1f)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Suppl. ${l.supplementsDone}/2", style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = { vm.supplementDone() }) { Text("+ taken") }
                }
            }
        }

        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Calories ${targets.calories} kcal · Protein ${targets.proteinG} g",
                    style = MaterialTheme.typography.titleMedium)
                Text("Carbs ${targets.carbsG} g · Fat ${targets.fatG} g · Fiber ${targets.fiberG} g",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card {
            Text(
                "\u201C${quotes[day % quotes.size]}\u201D",
                Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}
