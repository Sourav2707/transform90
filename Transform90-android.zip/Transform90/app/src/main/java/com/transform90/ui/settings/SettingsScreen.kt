package com.transform90.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.transform90.domain.PlanGenerator
import com.transform90.ui.dashboard.DashboardViewModel

@Composable
fun SettingsScreen(vm: DashboardViewModel = hiltViewModel()) {
    val profile by vm.profile.collectAsStateWithLifecycle(initialValue = null)
    val p = profile ?: return
    val bmi = PlanGenerator.bmi(p)
    val bmr = PlanGenerator.bmr(p)
    val tdee = PlanGenerator.tdee(p)
    val t = PlanGenerator.targets(p)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Calculators", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("BMI: ${"%.1f".format(bmi)}")
                Text("BMR: $bmr kcal")
                Text("TDEE: $tdee kcal")
                Text("Daily target: ${t.calories} kcal")
                Text("Protein: ${t.proteinG} g · Water: ${t.waterMl} ml")
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Progression rule", style = MaterialTheme.typography.titleMedium)
                Text("Every exercise's target weight increases by +2.5 kg automatically, " +
                    "once per week, from the day you set your starting weight — regardless of reps completed.")
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Reminders", style = MaterialTheme.typography.titleMedium)
                Text("Water · every 2 hours (waking hours)")
                Text("Workout · 1 hour after wake-up")
                Text("Supplements · morning & post-workout")
                Text("Sleep · 30 min before bedtime")
                Text("Reminders survive phone restarts via WorkManager.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("About", style = MaterialTheme.typography.titleMedium)
                Text("Exercise demo clips: your own uploaded workout video, cropped per exercise.")
                Text("This app gives general fitness guidance, not medical advice. " +
                    "Consult a doctor before starting a new diet or training program.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
