package com.transform90.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val age: Int,
    val gender: String,
    val heightCm: Float,
    val weightKg: Float,
    val targetWeightKg: Float,
    val bodyFatPct: Float?,
    val fitnessLevel: String,
    val goal: String,
    val location: String,
    val daysPerWeek: Int,
    val durationMin: Int,
    val foodPref: String,
    val wakeTime: String,
    val sleepTime: String,
    val startEpochDay: Long
)

@Entity(tableName = "daily_log")
data class DailyLog(
    @PrimaryKey val epochDay: Long,
    val workoutDone: Boolean = false,
    val waterMl: Int = 0,
    val mealsDone: Int = 0,
    val supplementsDone: Int = 0,
    val caloriesEaten: Int = 0,
    val proteinG: Int = 0
)

@Entity(tableName = "weight_entry")
data class WeightEntry(
    @PrimaryKey val epochDay: Long,
    val weightKg: Float,
    val bodyFatPct: Float? = null,
    val waistCm: Float? = null,
    val chestCm: Float? = null,
    val hipCm: Float? = null,
    val armCm: Float? = null,
    val thighCm: Float? = null
)

@Entity(tableName = "set_log")
data class SetLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val epochDay: Long,
    val exerciseId: String,
    val setIndex: Int,
    val weightKg: Float,
    val reps: Int
)

/** Weekly straight-weight-increase progression, one row per fixed exercise. */
@Entity(tableName = "exercise_weight")
data class ExerciseWeight(
    @PrimaryKey val exerciseId: String,
    val startingWeightKg: Float,
    val incrementKg: Float = 2.5f,
    val startEpochDay: Long
)

/** A fixed exercise tied to a bundled video clip (assets/videos/dayN/Name.mp4). */
data class Exercise(
    val id: String,
    val name: String,
    val dayKey: String,        // "day1".."day6"
    val videoPath: String,     // e.g. "videos/day1/Barbell-Flat-Bench-Press.mp4"
    val sets: Int,
    val repRange: String       // "8-12"
)
