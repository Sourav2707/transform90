package com.transform90.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val age: Int,
    val gender: String,          // Male / Female
    val heightCm: Float,
    val weightKg: Float,
    val targetWeightKg: Float,
    val bodyFatPct: Float?,      // optional
    val fitnessLevel: String,    // Beginner / Intermediate / Advanced
    val goal: String,            // Fat Loss / Muscle Gain / Recomposition ...
    val location: String,        // Home / Gym
    val daysPerWeek: Int,
    val durationMin: Int,
    val foodPref: String,        // Veg / Eggetarian / Non-Veg / Vegan
    val wakeTime: String,        // "06:30"
    val sleepTime: String,       // "22:30"
    val startEpochDay: Long      // plan Day 1
)

@Entity(tableName = "daily_log")
data class DailyLog(
    @PrimaryKey val epochDay: Long,
    val workoutDone: Boolean = false,
    val waterMl: Int = 0,
    val mealsDone: Int = 0,
    val supplementsDone: Int = 0,
    val caloriesEaten: Int = 0,
    val proteinG: Int = 0
)

@Entity(tableName = "weight_entry")
data class WeightEntry(
    @PrimaryKey val epochDay: Long,
    val weightKg: Float,
    val bodyFatPct: Float? = null,
    val waistCm: Float? = null,
    val chestCm: Float? = null,
    val hipCm: Float? = null,
    val armCm: Float? = null,
    val thighCm: Float? = null
)

@Entity(tableName = "set_log")
data class SetLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val epochDay: Long,
    val exerciseId: String,
    val setIndex: Int,
    val weightKg: Float,
    val reps: Int
)

/** Exercise loaded from bundled open-source dataset (free-exercise-db, public domain). */
data class Exercise(
    val id: String,
    val name: String,
    val category: String,        // strength / cardio / stretching ...
    val primaryMuscles: List<String>,
    val secondaryMuscles: List<String>,
    val equipment: String,
    val level: String,
    val instructions: List<String>,
    val images: List<String>     // relative paths inside assets/exercises/
)
