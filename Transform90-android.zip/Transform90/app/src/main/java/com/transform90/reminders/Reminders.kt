package com.transform90.reminders

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime

object Reminders {
    private data class Slot(val name: String, val time: LocalTime, val text: String)

    fun scheduleAll(ctx: Context, wake: String, sleep: String) {
        val wakeT = runCatching { LocalTime.parse(wake) }.getOrDefault(LocalTime.of(6, 30))
        val sleepT = runCatching { LocalTime.parse(sleep) }.getOrDefault(LocalTime.of(22, 30))

        val slots = listOf(
            Slot("wakeup", wakeT, "Good morning! Start with a glass of water 💧"),
            Slot("workout", wakeT.plusHours(1), "Workout time — Day plan is ready 💪"),
            Slot("water_noon", LocalTime.of(12, 0), "Hydration check — how many ml so far?"),
            Slot("lunch", LocalTime.of(13, 30), "Lunch: protein + carb + veggies 🍛"),
            Slot("supplement", LocalTime.of(17, 0), "Whey + creatine reminder"),
            Slot("dinner", LocalTime.of(20, 30), "Light dinner, high protein 🥗"),
            Slot("sleep", sleepT.minusMinutes(30), "Wind down — sleep builds muscle 😴")
        )

        val wm = WorkManager.getInstance(ctx)
        slots.forEach { s ->
            val now = LocalDateTime.now()
            var next = now.toLocalDate().atTime(s.time)
            if (next.isBefore(now)) next = next.plusDays(1)
            val delay = Duration.between(now, next)
            val req = PeriodicWorkRequestBuilder<ReminderWorker>(Duration.ofDays(1))
                .setInitialDelay(delay)
                .setInputData(workDataOf("title" to "Transform 90", "text" to s.text, "id" to s.name.hashCode()))
                .build()
            wm.enqueueUniquePeriodicWork("t90_${s.name}", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}

@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted ctx: Context,
    @Assisted params: WorkerParameters
) : Worker(ctx, params) {
    override fun doWork(): Result {
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        val notif = NotificationCompat.Builder(applicationContext, "reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(inputData.getString("title") ?: "Transform 90")
            .setContentText(inputData.getString("text") ?: "")
            .setAutoCancel(true)
            .build()
        nm.notify(inputData.getInt("id", 1), notif)
        return Result.success()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // WorkManager restores periodic work automatically.
    }
}
