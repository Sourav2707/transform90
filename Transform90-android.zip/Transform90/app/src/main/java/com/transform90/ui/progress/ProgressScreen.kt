package com.transform90.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.transform90.data.db.LogDao
import com.transform90.data.model.WeightEntry
import com.transform90.ui.theme.Ember
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class ProgressViewModel @Inject constructor(private val logDao: LogDao) : ViewModel() {
    val weights = logDao.weights()
    val logs = logDao.all()

    fun addWeight(kg: Float, waist: Float?) = viewModelScope.launch {
        logDao.addWeight(WeightEntry(LocalDate.now().toEpochDay(), kg, waistCm = waist))
    }
}

@Composable
fun ProgressScreen(vm: ProgressViewModel = hiltViewModel()) {
    val weights by vm.weights.collectAsStateWithLifecycle(initialValue = emptyList())
    val logs by vm.logs.collectAsStateWithLifecycle(initialValue = emptyList())
    var kg by remember { mutableStateOf("") }
    var waist by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Progress", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Log today", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(kg, { kg = it }, label = { Text("Weight kg") },
                        modifier = Modifier.weight(1f))
                    OutlinedTextField(waist, { waist = it }, label = { Text("Waist cm") },
                        modifier = Modifier.weight(1f))
                }
                Button(
                    onClick = {
                        kg.toFloatOrNull()?.let { vm.addWeight(it, waist.toFloatOrNull()); kg = ""; waist = "" }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save") }
            }
        }

        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Weight trend", style = MaterialTheme.typography.titleMedium)
                if (weights.size < 2) {
                    Text("Add at least two entries to see the chart.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val min = weights.minOf { it.weightKg } - 0.5f
                    val max = weights.maxOf { it.weightKg } + 0.5f
                    Canvas(Modifier.fillMaxWidth().height(160.dp).padding(top = 12.dp)) {
                        val pts = weights.mapIndexed { i, w ->
                            Offset(
                                x = size.width * i / (weights.size - 1),
                                y = size.height * (1 - (w.weightKg - min) / (max - min))
                            )
                        }
                        for (i in 0 until pts.size - 1) {
                            drawLine(Ember, pts[i], pts[i + 1], strokeWidth = 6f, cap = StrokeCap.Round)
                        }
                        pts.forEach { drawCircle(Ember, radius = 9f, center = it) }
                    }
                    Text(
                        "Start ${weights.first().weightKg} kg → now ${weights.last().weightKg} kg " +
                            "(${"%+.1f".format(weights.last().weightKg - weights.first().weightKg)} kg)",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("This journey", style = MaterialTheme.typography.titleMedium)
                val done = logs.count { it.workoutDone }
                val streak = run {
                    var s = 0
                    var d = LocalDate.now().toEpochDay()
                    val byDay = logs.associateBy { it.epochDay }
                    while (byDay[d]?.workoutDone == true) { s++; d-- }
                    s
                }
                Text("Workouts completed: $done")
                Text("Current streak: $streak days 🔥")
                Text("Water logged: ${logs.sumOf { it.waterMl } / 1000f} L total")
            }
        }
    }
}
