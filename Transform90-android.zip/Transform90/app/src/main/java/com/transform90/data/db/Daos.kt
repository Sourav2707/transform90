package com.transform90.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.transform90.data.model.DailyLog
import com.transform90.data.model.ExerciseWeight
import com.transform90.data.model.SetLog
import com.transform90.data.model.UserProfile
import com.transform90.data.model.WeightEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun profile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(p: UserProfile)
}

@Dao
interface LogDao {
    @Query("SELECT * FROM daily_log WHERE epochDay = :day")
    fun day(day: Long): Flow<DailyLog?>

    @Query("SELECT * FROM daily_log ORDER BY epochDay")
    fun all(): Flow<List<DailyLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: DailyLog)

    @Query("SELECT * FROM weight_entry ORDER BY epochDay")
    fun weights(): Flow<List<WeightEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addWeight(w: WeightEntry)

    @Insert
    suspend fun addSet(s: SetLog)

    @Query("SELECT * FROM set_log WHERE exerciseId = :ex ORDER BY id DESC LIMIT 12")
    suspend fun recentSets(ex: String): List<SetLog>
}

@Dao
interface ProgressionDao {
    @Query("SELECT * FROM exercise_weight WHERE exerciseId = :id")
    fun forExercise(id: String): Flow<ExerciseWeight?>

    @Query("SELECT * FROM exercise_weight")
    fun all(): Flow<List<ExerciseWeight>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(w: ExerciseWeight)
}
