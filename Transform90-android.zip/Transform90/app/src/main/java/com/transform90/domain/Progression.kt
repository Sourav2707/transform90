package com.transform90.domain

import com.transform90.data.model.ExerciseWeight
import kotlin.math.floor

/**
 * Straight weekly weight increase: every 7 days since the exercise's start
 * date, the target weight goes up by a fixed increment — independent of
 * reps or performance.
 */
object Progression {

    fun targetWeightKg(w: ExerciseWeight, todayEpochDay: Long): Float {
        val weeksElapsed = floor((todayEpochDay - w.startEpochDay) / 7.0).toInt().coerceAtLeast(0)
        return w.startingWeightKg + w.incrementKg * weeksElapsed
    }

    fun weekNumber(w: ExerciseWeight, todayEpochDay: Long): Int =
        floor((todayEpochDay - w.startEpochDay) / 7.0).toInt().coerceAtLeast(0) + 1
}
