# Transform 90 — Android App

A 90-day body transformation app: personalized workout plans, macro-calculated
nutrition with food swapping, water tracking, supplement & meal reminders,
progress charts and streaks. Offline-first — everything is stored locally in Room.

## Tech stack
- Kotlin + Jetpack Compose (Material 3)
- MVVM + Hilt dependency injection
- Room database (offline-first)
- WorkManager daily reminders (persist across reboots)
- Coil image loading
- Open-source exercise data & photos: [free-exercise-db](https://github.com/yuhonas/free-exercise-db) (Unlicense / public domain)

## Build the APK — no PC needed (phone only)

1. Create a free account at **github.com** in your phone browser.
2. Tap **+ → New repository** → name it `transform90` → Create.
3. On the repo page tap **Add file → Upload files** and upload the *contents* of this
   zip (you can unzip on your phone with any file manager, then upload folder by folder —
   or use the github.dev editor). Commit to `main`.
4. Go to the **Actions** tab → the "Build APK" workflow starts automatically
   (or tap **Run workflow**). It takes ~5–8 minutes.
5. Open the finished run → scroll to **Artifacts** → download **Transform90-APK**.
6. Unzip it, tap `app-debug.apk`, allow "Install from unknown sources" → installed. Done.

The cloud build also downloads the full 800+ exercise photo dataset automatically,
so your APK includes all the images.

## Build the APK — with a PC (alternative)

1. Install **Android Studio** (Koala or newer).
2. *(Recommended)* Download the full exercise dataset with photos:
   ```bash
   bash scripts/download_assets.sh
   ```
   Without this step the app still works with the bundled 30-exercise starter set (no photos).
3. Open the project folder in Android Studio and let Gradle sync.
4. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. The APK appears in `app/build/outputs/apk/debug/`. Copy it to your phone and install
   (enable "Install from unknown sources").

For a signed release APK: **Build → Generate Signed Bundle / APK** and create a keystore.

## How the plan generation works
- **BMR** via Mifflin-St Jeor, **TDEE** from training frequency.
- Calorie target: −550 kcal for fat loss (floor 1,400), −250 for recomposition, +250 for muscle gain.
- Protein 1.8 g/kg bodyweight; fat 25% of calories; carbs fill the remainder.
- Water target: 35 ml/kg + activity bonus.
- Workout split auto-selected from days/week (3=full-body split, 4=upper/lower+, 5–6=PPL variants),
  exercises filtered by equipment (Home vs Gym) and fitness level, rotated weekly for variety.
- Three phases: Days 1–30 (3×12, learn form), 31–60 (4×10, load up), 61–90 (4×8–10, intensity).

## Project layout
```
app/src/main/java/com/transform90/
  data/        Room entities, DAOs, exercise repository
  domain/      PlanGenerator (BMR/TDEE/macros, 90-day plan)
  reminders/   WorkManager reminder scheduling + boot receiver
  ui/          Compose screens: onboarding, dashboard, workout player,
               nutrition, progress, settings
```

## Roadmap ideas (not in v1)
Barcode food scanning, progress photos, cloud backup, voice-guided player,
heart-rate integration, exercise search screen, gamification badges.

## Disclaimer
This app provides general fitness information, not medical advice.
Consult a doctor before starting a new diet or training program.
