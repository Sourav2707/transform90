# Transform 90 — Android App

A 90-day body transformation app built around a fixed Day1–Day6 workout split
(from your own uploaded gym video, auto-cropped per exercise), macro-calculated
nutrition with food swapping, water tracking, reminders, and per-exercise
weekly weight progression. Offline-first — everything is stored locally in Room.

## Workout structure
- Day1: Chest · Day2: Back · Day3: Biceps/Forearms · Day4: Triceps/Abs
- Day5: Shoulders/Traps · Day6: Legs · Day7: Rest (cycle repeats for 90 days)
- Each exercise has its own short looping video clip cut from your source video
  (assets/videos/dayN/ExerciseName.mp4), played silently via ExoPlayer.

## Weight progression
- The first time you open an exercise in the workout player, enter your
  starting weight.
- From that date, the app adds **+2.5 kg every 7 days automatically** —
  a straight weekly increase, independent of reps completed.
- See all lifts and their current week/target under the Progress tab.

## Tech stack
- Kotlin + Jetpack Compose (Material 3)
- MVVM + Hilt dependency injection
- Room database (offline-first)
- ExoPlayer (media3) for bundled exercise video clips
- WorkManager daily reminders (persist across reboots)

## Build the APK — no PC needed (phone only)

1. Create a free account at **github.com** in your phone browser.
2. Tap **+ → New repository** → name it `transform90` → Create.
3. **Add file → Upload files** → upload `Transform90-android.zip` exactly as-is → Commit.
4. **Add file → Create new file** → filename: `.github/workflows/build-apk.yml`
   → paste the workflow contents provided separately → Commit.
5. Go to the **Actions** tab — the build starts automatically (~5 min).
6. Open the finished run → **Artifacts** → download **Transform90-APK**.
7. Unzip, tap `app-debug.apk`, allow "Install from unknown sources" → installed.

## Project layout
```
app/src/main/java/com/transform90/
  data/        Room entities (incl. ExerciseWeight), DAOs
  domain/      WorkoutPlan (fixed Day1-6 exercises + video paths),
               Progression (weekly weight increase), Calculators (BMR/TDEE/macros)
  reminders/   WorkManager reminder scheduling + boot receiver
  ui/          Compose screens: onboarding, dashboard, workout (day picker +
               video player + progression), nutrition, progress, settings
app/src/main/assets/videos/day1..day6/  Exercise demo clips
```

## Disclaimer
General fitness guidance, not medical advice. Consult a doctor before
starting a new diet or training program.
